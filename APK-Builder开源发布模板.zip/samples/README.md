# samples/ —— 示例项目

本目录用于存放可直接运行的示例 Smali 工程，便于演示与测试。

## 当前内容
空目录（占位）。

## 如何添加示例
每个示例是一个完整的 Smali 工程目录，结构与 `template/` 相同：

```
samples/hello/
├── AndroidManifest.xml
├── res/
│   ├── layout/
│   └── values/strings.xml
└── smali/com/example/...
```

添加后用 `build.sh` 直接构建即可验证：
```bash
./build.sh -i samples/hello -p com.example.hello -n "Hello"
```

## 建议的示例方向
- hello：最小可运行程序（已内置在 template，可作为首个示例）
- 多 Activity 跳转：演示 intent 与多页面
- 资源引用：演示 layout / drawable / strings 的 R 引用
- 权限演示：动态申请权限的 Smali 写法
