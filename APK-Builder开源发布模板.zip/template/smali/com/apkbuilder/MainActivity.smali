# 示例 Activity —— 编译后的可运行最小模板
# 对应模板 AndroidManifest.xml 中的 android:name=".MainActivity"
.class public Lcom/apkbuilder/MainActivity;
.super Landroid/app/Activity;

.field public static final TAG:Ljava/lang/String; = "APK-Builder"

.method public constructor <init>()V
    .registers 1
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 2
    # 调用父类 onCreate
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    # 加载布局 res/layout/activity_main.xml
    const v0, 0x7f030000
    invoke-virtual {p0, v0}, Landroid/app/Activity;->setContentView(I)V
    # 打印日志，便于验证 APK 正常运行
    const-string v0, "APK-Builder"
    const-string v1, "Hello, template is running!"
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    return-void
.end method
