# 构建指南（BUILD_GUIDE）

本文件详细说明 APK Builder 的构建原理、脚本参数与常见问题。

## 1. 构建原理（五步流水线）

```
template(Smali工程)
   │
   ├─ ① 渲染模板：替换 {{PACKAGE}} / {{APP_NAME}} 占位符
   │
   ├─ ② aapt 编译资源：res/ -> R.java + resources.ap_（生成包资源ID）
   │
   ├─ ③ smali.jar 汇编：smali/ -> classes.dex
   │
   ├─ ④ 组装：manifest + dex + 编译后资源 打成 unsigned.apk
   │
   └─ ⑤ apksigner 签名：生成可安装的 app-release.apk
```

## 2. build.sh 参数

| 参数 | 含义 | 默认值 |
| ---- | ---- | ---- |
| `-i` | 输入 Smali 工程目录 | `template` |
| `-o` | 输出 APK 路径 | `dist/app-release.apk` |
| `-p` | 包名 | `com.apkbuilder.demo` |
| `-n` | 应用名 | `APK Builder` |
| `-k` | 签名 key 名（对应 keys/） | `testkey` |
| `-d` | 调试模式（打印中间产物） | 关闭 |

也可用环境变量覆盖，如 `INPUT_DIR=myapp ./build.sh`。

## 3. 模板占位符

`template/AndroidManifest.xml` 与 `template/res/values/strings.xml` 中的：

- `{{PACKAGE}}` → 会被替换为 `-p` 指定的包名
- `{{APP_NAME}}` → 会被替换为 `-n` 指定的应用名

## 4. 生成全新应用三步走

```bash
# ① 复制模板为新项目
cp -r template myapp

# ② 修改代码（Smali 目录就是 app 的 dex 源码）
vim myapp/smali/com/apkbuilder/MainActivity.smali

# ③ 构建
./build.sh -i myapp -p com.example.myapp -n "MyApp" -o dist/myapp.apk
```

## 5. 常见问题

### 5.1 提示 `arm_aapt: cannot execute`
内置 `bin/arm_aapt` 是 ARM 平台二进制，x86/Windows 无法直接运行。
**解决**：从 Android SDK `build-tools/<version>/aapt` 替换，或下载对应平台 aapt 放入 `bin/`。

### 5.2 `smali.jar` 报版本错误
检查 `java -version`，需为 JDK 8 及以上。

### 5.3 安装提示签名不一致
同一设备重新安装需用相同签名 key，或先卸载旧版。

### 5.4 资源 ID 与 R 不匹配
修改 `res/layout/` 后，Smali 中的 `const v0, 0x7f03xxxx` 需与 `aapt` 生成的 R.java 对应。可用 `-d` 调试模式查看生成的 `gen/R.java` 确认。

### 5.5 运行闪退
抓 logcat 定位：
```bash
adb logcat -s APK-Builder:D *:S
```

## 6. 工具链定位（安卓端 vs PC 端）

> 本仓库 `bin/` 内置的工具链来自手机端 APK Builder，是**安卓端运行时版本**：

| 文件 | 真实格式 | 运行环境 |
| ---- | -------- | -------- |
| `arm_aapt` / `arm_aapt2` | ARM ELF 可执行文件 | 安卓（ARM 设备） |
| `smali.jar` | DEX 格式（内含 classes.dex） | 安卓 ART / Dalvik |
| `apksigner.jar` | DEX 格式（内含 classes.dex） | 安卓 ART / Dalvik |
| `android.jar` | 标准 JAR | 通用 |
| `zip` | shell 脚本（调用系统 zip） | 安卓 shell |

### 用法一：安卓端集成（推荐，开箱即用）
把这套工具链随你的安卓 App 打包（assets/），在 App 内调用：
- 用 `arm_aapt` 编译资源、`smali.jar` 汇编 dex、`apksigner.jar` 签名
- 适合做"手机端 APK 打包器"，与你的 APK Builder 定位一致

### 用法二：PC 端构建（需替换工具）
在 PC（x86/Windows/macOS）上跑 `build.sh` 前，把 `bin/` 替换为桌面版：
- `bin/smali.jar` → 下载 PC 版 smali（含 Main-Class）
- `bin/apksigner.jar` → 使用 Android SDK `build-tools/<ver>/apksigner.jar`
- `bin/arm_aapt` → 使用对应平台的 `aapt`
替换后 `./build.sh` 自动通过自检并开始构建。

> `build.sh` 内置自检，会自动识别当前工具链是否可被 PC JVM 驱动。

## 7. 进一步学习

- Smali 语法：`baksmali` 反编译任意 APK 后对照阅读
- 资源编译：参考 AOSP aapt 文档
- 签名机制：参考 apksigner / APK Signature Scheme v2

## 8. 合规提醒

- 仅用于你自己的应用、开源项目或已获授权的逆向学习
- 禁止反编译并重新分发商业付费软件的源码/资源
